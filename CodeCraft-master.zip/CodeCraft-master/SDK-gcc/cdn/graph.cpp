#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>

#include "graph.h"

using std::vector;
using std::sscanf;
using std::cout;
using std::ostream;

ostream& operator<<(ostream& os, const Edge& edge) {
    os << "Edge[index: " << edge.index
        << ", start: " << edge.start
        << ", end: " << edge.end
        << ", vol: " << edge.vol
        << ", cost: " << edge.cost << "]";
    return os;
}

Graph::Graph(char **topo, int line_num) {
    Initialize(topo, line_num);
    MapEdgeToVertex();
}

// initialize our Graph from topo file
void Graph::Initialize(char **topo, int line_num) {
    int idx = 0;
    sscanf(topo[idx++], "%d%d%d", &nVertexs, &nEdges, &nConsumers);
    
    ++idx; // skip empty line, server fee starts
    sscanf(topo[idx++], "%d", &serverFee);

    ++idx; // skip empty line, vertex starts
    int edge_index = 0;
    int start, end, vol, cost;
    while (topo[idx] != nullptr) {
        sscanf(topo[idx++], "%d%d%d%d", &start, &end, &vol, &cost);
        edgesData.emplace_back(edge_index++, start, end, vol, cost);
        edgesData.emplace_back(edge_index++, end, start, vol, cost);
    }

    ++idx; // skip empty line, consumer starts
    consumerVertex.resize(nConsumers);
    demands.resize(nVertexs);
    totalDemands = 0;
    int consumerId, vertexId, demand;
    while (topo[idx] != nullptr) {
        sscanf(topo[idx++], "%d%d%d", &consumerId, &vertexId, &demand); 
        demands[vertexId] = demand;
        consumerVertex[consumerId] = vertexId;
        totalDemands += demand;
    }
}

// turn the ajacent linked table into {vertex : [edges's index]}
void Graph::MapEdgeToVertex() {
    inQuery.resize(nVertexs);
    outQuery.resize(nVertexs);

    for (int i = 0; i <= nEdges * 2; ++i) {
        inQuery[edgesData[i].start].push_back(i);
        outQuery[edgesData[i].end].push_back(i);
    }
}
