#ifndef _GRAPH_H_
#define _GRAPH_H_

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>

using std::vector;
using std::ostream;

struct Edge {
    int index;  // row number of sorted topo information
    int start;
    int end;
    int vol;
    int cost;

    Edge(int i, int s, int e, int v, int c):
        index(i), start(s), end(e), vol(v), cost(c) { /* empty */ }
    friend ostream& operator<<(ostream& os, const Edge& edge);
};

struct Graph {
    Graph(char **topo, int line_num);
    void Initialize(char **topo, int line_num);
    void MapEdgeToVertex();

    int nVertexs;
    int nEdges;
    int nConsumers;
    int serverFee;
    int totalDemands;

    // store each consumer node's demands
    vector<double> demands;

    // store [consumerId : vertexId]
    vector<int> consumerVertex;

    // contains 2*E elements
    vector<Edge> edgesData; 

    // the indexs of all the edges' that flow into this node
    vector<vector<int>> inQuery;

    // the indexs of all the edge's flow out from this node
    vector<vector<int>> outQuery;

};

#endif // _GRAPH_H_
