#include <vector>
#include "particle.h"

using std::vector;

Particle::Particle(int e, int n):
    edges(e),
    nodes(n),
    F(2 * edges, vector<double>(nodes)),
    A(nodes),
    S(nodes)
{
    // Empty
}

void Particle::update(vector<double>& vec) {
    int idx = 0;
    for (int i = 0; i != 2 * edges; ++i) {
        for (int j = 0; j != nodes; ++j) {
             F[i][j] = vec[idx++];
        }
    }

    for (int i = 0; i != nodes; ++i) {
        A[i] = vec[idx++];
    }

    for (int i = 0; i != nodes; ++i) {
        S[i] = vec[idx++];
    }
}
