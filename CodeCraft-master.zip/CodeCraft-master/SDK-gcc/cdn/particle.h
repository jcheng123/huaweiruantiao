#ifndef _PARTICLE_H_
#define _PARTICLE_H_

#include <vector>

using std::vector;

struct Particle {
    Particle(int e, int n);
    void update(vector<double>& vec);

    int edges;
    int nodes;

    vector<vector<double>> F;
    vector<double> A;
    vector<double> S;
};

#endif // _PARTICLE_H_
