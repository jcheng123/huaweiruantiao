#include <vector>
#include <cmath>
#include <algorithm>

#include "pso.h"

using std::vector;
using std::copy;
using std::min_element;
using std::rand;
using std::max;
using std::min;


inline 
ParticleSwarmOptimization::ParticleSwarmOptimization(
        int nIter, int nParticle, int nDim, double c1, double c2):

    // for pso parameters
    nIter(nIter),
    nParticle(nParticle),
    nDim(nDim),
    c1(c1),
    c2(c2),

    // for training X
    Xmax(nDim),
    Xmin(nDim),
    X(nParticle, vector<double>(nDim)),

    // for velocity stuff
    Vmax(nDim),
    Vmin(nDim),
    V(nParticle, vector<double>(nDim)),

    // for particle solution
    fitnesses(nParticle),
    pBestFits(nParticle),
    pBests(nParticle, vector<double>(nDim)),
    bests(nIter),

    // global result
    gBestFit(0),
    gBest(nDim)
{
    /* empty */
}


ParticleSwarmOptimization::~ParticleSwarmOptimization() {
    // empty
}

void ParticleSwarmOptimization::optimize() {
    double w;
	double minFit;
	int    minFitIdx;
    // initialize Xmin and Xmax
    initialize();

    const double rand_01 = ((double)rand() / (double)RAND_MAX);

    fitnessFunc();

    copy(fitnesses.begin(), fitnesses.end(), pBestFits.begin());

    minFit = *min_element(fitnesses.begin(), fitnesses.end());
	gBestFit = minFit;

	minFitIdx = min_element(fitnesses.begin(), fitnesses.end()) - fitnesses.begin();
    copy(X[minFitIdx].begin(), X[minFitIdx].end(), gBest.begin());

    // set velocity range
	for (int i = 0; i < nDim; i++) {
		Vmax[i] = 0.2 * (Xmax[i] - Xmin[i]);
		Vmin[i] = -Vmax[i];
	}

    // iterative update local and global best solution 
	for (int t = 0; t < nIter; t++) {
		w = 0.8 - 0.7 * t / nIter;
		for (int i = 0; i < nParticle; i++) {
			if (fitnesses[i] < pBestFits[i]) {
				pBestFits[i] = fitnesses[i];  
                copy(X[i].begin(), X[i].end(), pBests[i].begin());
			}
		}

        // adjust velocity and solution
		for (int i = 0; i < nParticle; i++) {
			for (int j = 0; j < nDim; j++) {
                V[i][j] = min(max((w * V[i][j] + rand_01 * c1 * (pBests[i][j] - X[i][j])
                        + rand_01 * c2 * (gBest[j] - X[i][j])), Vmin[j]), Vmax[j]);
                X[i][j] = min(max((X[i][j] + V[i][j]), Xmin[j]), Xmax[j]);
			}
		}

        fitnessFunc();

		minFit = *min_element(fitnesses.begin(), fitnesses.end());
		minFitIdx = min_element(fitnesses.begin(), fitnesses.end()) - fitnesses.begin();

		if (minFit < gBestFit) {
			gBestFit = minFit;
            copy(X[minFitIdx].begin(), X[minFitIdx].end(), gBest.begin());
		}

		bests[t] = gBestFit;
	}
}

