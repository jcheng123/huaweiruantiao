#ifndef _PSO_H_
#define _PSO_H_

#include <vector>

using std::vector;

// Abstract class, offer PSO algorithm
// User should derived it and implement fitnessFunc
class ParticleSwarmOptimization {
public:
    ParticleSwarmOptimization(
            int nIter, int nParticle, int nDim, double c1, double c2);

    virtual ~ParticleSwarmOptimization();

    virtual void fitnessFunc() = 0;
    virtual void initialize() = 0;
    virtual void optimize();

protected:
    int nIter;
    int nParticle;
    int nDim;
    double c1;
    double c2;

    vector<double> Xmax;
    vector<double> Xmin;
    vector<vector<double>> X;

    vector<double> Vmax;
    vector<double> Vmin;
    vector<vector<double>> V;

    vector<double> fitnesses;

    vector<double> pBestFits;
    vector<vector<double>> pBests;
    vector<double> bests; // [nIter * 1] : for each iter: store objective function's value

    double gBestFit;            // (the last one) best objective function's value
    vector<double> gBest;
};

#endif // _PSO_H_
