#include <vector>
#include <cmath>
#include <algorithm>
#include <iostream>

#include "graph.h"
#include "particle.h"
#include "util.h"
#include "pso.h"
#include "server_pso.h"

using std::vector;
using std::max;
using std::min;

inline
ServerPSO::ServerPSO(int nIter, int nParticle, int nDim, double c1, double c2,
        const Graph *pGraph, double penaltyFactor):
    // Init PSO
    ParticleSwarmOptimization(
            nIter,
            nParticle,
            nDim,
            c1,
            c2),
    graph(*pGraph),
    penaltyFactor(penaltyFactor),
    ones(graph.nVertexs, 1.0)
{
    // Empty
}

inline
ServerPSO::~ServerPSO() {
    // Empty
}

void
ServerPSO::initialize() {
    // init {F[i][j], A, S} min
    for (int i = 0; i < nDim; ++i) {
        Xmin[i] = 0;
    }
    
    // init F[i][j] max
    for (int i = 0; i < 2 * graph.nEdges; ++i) {
        for (int j = 0; j < graph.nVertexs; ++j) {
            // set each edge's max F[i][j] = edge's volume
            Xmax[i * graph.nVertexs + j] = graph.edgesData[i].vol;
        }
    }

    // init A max
    int offset = 2 * graph.nEdges * graph.nVertexs;
    for (int i = 0; i < graph.nVertexs; ++i) {
        // set A to all 1
        Xmax[offset + i] = 1;
    }

    // init S max
    offset += graph.nVertexs;
    for (int i = 0; i < graph.nVertexs; ++i) {
        Xmax[offset + i] = graph.totalDemands;
    }
}

void
ServerPSO::fitnessFunc() {

    Particle particle(graph.nEdges, graph.nVertexs);

    for (int i = 0; i != nParticle; ++i) {
        // for every particle
        particle.update(X[i]);
        double serverCost = (particle.A * ones) * graph.serverFee;
        double flowCost = 0;
        for (int i = 0; i < graph.nEdges * 2; ++i) {
            flowCost += (particle.A * particle.F[i]) * graph.edgesData[i].cost;
        }

        fitnesses[i] = serverCost + flowCost + penaltyFactor * penalty(particle);
    }
}

double
ServerPSO::penalty(const Particle& particle) {

    // get max{0, At * F(i,j) - V(i,j)}
    double flowConstrain = 0;
    for (int i = 0; i != particle.edges * 2; ++i) {
        // flow = At * F[i][j]
        double flow = 0;
        for (int j = 0; j != particle.nodes; ++j) {
            flow += particle.A[j] * particle.F[i][j];
        }
        flowConstrain += pow(max(0.0, flow - graph.edgesData[i].vol), 2);
    }

    // get min{0, S[i]}
    double serverConstrain = 0;
    for (int i = 0; i != particle.nodes; ++i) {
        serverConstrain += pow(min(0.0, particle.S[i]), 2);
    }

     // get min{0, F[i,j]}
    double minFlowConstrain = 0;
    for (int i = 0; i != particle.edges * 2; ++i) {
        for (int j = 0; j != particle.nodes; ++j) {
            minFlowConstrain += pow(min(0.0, particle.F[i][j]), 2);
        }
    }

    // get sum { A[i] * S[i] + sum{ A*[F(i,j) - F(j,i)] } - demand[i] } ^ 2
    double nodeConstrain = 0;
    for (int i = 0; i != particle.nodes; ++i) {
        double serverOut = particle.A[i] * particle.S[i];
        // for each node, get all input flow's edge's line number

        double iodegree = 0;
        int connectedEdges = graph.inQuery[i].size();

        for (int j = 0; j != connectedEdges; ++j) {
            int indegree = graph.inQuery[i][j];
            int outdegree = graph.outQuery[i][j];

            // tmp is a copy of F[indegree], tmp - F[outdegree] -> tmp
            vector<double> tmp(particle.F[indegree].begin(), particle.F[indegree].end());
            iodegree += particle.A * (tmp - particle.F[outdegree]);
        }

        nodeConstrain += pow(serverOut + iodegree - graph.demands[i], 2);
    }

    // max { 0, At * 1 - |C| } ^ 2
    double maxServerConstrain =
        pow(max(0.0, (particle.A * ones) - graph.nConsumers), 2);

    // sum { Ai ^ 2 - Ai } ^ 2
    double onezeroConstrain = 0;
    for (int i = 0; i < particle.nodes; ++i) {
        onezeroConstrain += pow(pow(particle.A[i], 2) - particle.A[i], 2);
    }

    return flowConstrain + nodeConstrain + minFlowConstrain + serverConstrain
        + maxServerConstrain + onezeroConstrain;
}
