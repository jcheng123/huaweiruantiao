#ifndef _SERVER_PSO_H_
#define _SERVER_PSO_H_

#include "graph.h"
#include "particle.h"
#include "pso.h"

class ParticleSwarmOptimization;

class ServerPSO: public ParticleSwarmOptimization {
public:
    ServerPSO(int nIter, int nParticle, int nDim, double c1, double c2, const Graph *pGraph, double penaltyFactor);

    ~ServerPSO();
    
    virtual void fitnessFunc();
    virtual void initialize();
    double penalty(const Particle& particle);

private:
    const Graph &graph;
    double penaltyFactor;

    vector<double> ones;
};

#endif // _SERVER_PSO_H_
