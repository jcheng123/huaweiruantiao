#include <vector>

#include "util.h"

using std::vector;

double operator*(const vector<double>& A, const vector<double>& B) {
    if (A.size() != B.size()) {
        throw std::invalid_argument("Can not multiply. Vector's size are not match!");
    }

    double ans = 0;
    for (size_t i = 0; i < A.size(); ++i) {
        ans += A[i] * B[i];
    }

    return ans;
}

vector<double>& operator-(vector<double>& A, const vector<double>& B) {
    if (A.size() != B.size()) {
        throw std::invalid_argument("Can not subtract. Vector's size are not match!");
    }

    for (size_t i = 0; i < A.size(); ++i) {
        A[i] -= B[i];
    }

    return A;
}

