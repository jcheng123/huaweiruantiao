#ifndef _UTIL_H_
#define _UTIL_H_

#include <vector>
#include <iostream>

using std::vector;

double operator*(const vector<double>& A, const vector<double>& B);
vector<double>& operator-(vector<double>& A, const vector<double>& B);

template<typename T>
void print_vector(const vector<T>& vec) {
    for (int i = 0; i != vec.size(); ++i) {
        std::cout << vec[i] << " ";
    }
    std::cout << "\n";
}

 
#endif // _UTIL_H_
