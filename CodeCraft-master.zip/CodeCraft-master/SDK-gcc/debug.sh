#!/bin/bash

lldb bin/cdn case0.txt out.txt
