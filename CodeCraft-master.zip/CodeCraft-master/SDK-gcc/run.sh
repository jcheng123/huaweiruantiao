#!/bin/bash

./build.sh
bin/cdn case0.txt out.txt
